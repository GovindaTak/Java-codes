package core;

public enum Category {
	CAT, DOG, RABBIT, FISH;
}
