package tester;

import static PenOperations.PenOperations.addPen;
import static PenOperations.PenOperations.displayAll;
import static PenOperations.PenOperations.removePens;
import static PenOperations.PenOperations.setDiscount;
import static PenOperations.PenOperations.sortbyId;
import static PenOperations.PenOperations.sortbyLastUpdateDate;
import static PenOperations.PenOperations.sortbyNameAndPrice;
import static PenOperations.PenOperations.updateStock;
import static io.IoOperations.importData;
import static io.IoOperations.printData;
import static io.IoOperations.printDataAsBinary;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import core.Brand;
import core.Material;
import core.Pen;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		boolean flag = false;
		Map<Integer, Pen> penMap = new HashMap<>();
		//populatedMap(penMap);
		try (Scanner sc = new Scanner(System.in)) {
			while (!flag) {
				System.out.println("1)Add new pen\n" + "2)Update stock \n" + "3)set discount\n"
						+ "4)remove pens not sold in last 9 months\n" + "5)display all \n" + "6.sort by penId\n"
						+ "7)sort by last Update date\n" + "8)sortbyNameAndPrice\n" + "9)printData\n"
						+ "10)printDataAsBinary\n" + "11)importData\n" + "12)exit");
				try {
					switch (sc.nextInt()) {
					case 1:
						addPen(penMap, sc);
						break;
					case 2:
						updateStock(penMap, sc);
						break;
					case 3:
						setDiscount(penMap);
						break;
					case 4:
						removePens(penMap);
						break;
					case 5:
						displayAll(penMap);
						break;
					case 6:
						sortbyId(penMap);
						break;

					case 7:
						sortbyLastUpdateDate(penMap);
						break;
					case 8:
						sortbyNameAndPrice(penMap);
						break;
					case 9:
						printData(penMap);
						break;
					case 10:
						printDataAsBinary(penMap);
						break;
					case 11:
						penMap=importData(penMap);
						break;
					case 12:
						flag = true;
						System.out.println("Bye !");
						break;

					default:
						System.out.println("Invalid choice !");
						break;
					}
				} catch (Exception e) {
					e.printStackTrace();
					sc.nextLine();
				}
			}

		}

	}

	private static void populatedMap(Map<Integer, Pen> penMap) {
		// TODO Auto-generated method stub
		Pen p1 = new Pen(Brand.valueOf("REYNOLDS"), "black", Material.valueOf("METAL"), 35,
				LocalDate.parse("2022-03-21"), LocalDate.parse("2023-01-01"), 5.0);
		Pen p2 = new Pen(Brand.valueOf("PARKER"), "blue", Material.valueOf("METAL"), 30, LocalDate.parse("2021-03-21"),
				LocalDate.parse("2023-05-01"), 10.0);
		Pen p3 = new Pen(Brand.valueOf("REYNOLDS"), "red", Material.valueOf("ALLOYSTEEL"), 15,
				LocalDate.parse("2022-08-21"), LocalDate.parse("2023-09-01"), 15.0);
		Pen p4 = new Pen(Brand.valueOf("CELLO"), "green", Material.valueOf("PLASTIC"), 10,
				LocalDate.parse("2020-03-21"), LocalDate.parse("2023-10-01"), 25.0);
		Pen p5 = new Pen(Brand.valueOf("PARKER"), "blue", Material.valueOf("ALLOYSTEEL"), 25,
				LocalDate.parse("2023-03-21"), LocalDate.parse("2023-10-01"), 15.0);
		Pen p6 = new Pen(Brand.valueOf("CELLO"), "brown", Material.valueOf("METAL"), 30, LocalDate.parse("2021-03-21"),
				LocalDate.parse("2023-05-01"), 10.0);
		Pen p7 = new Pen(Brand.valueOf("PARKER"), "blue", Material.valueOf("METAL"), 30, LocalDate.parse("2021-03-21"),
				LocalDate.parse("2023-05-01"), 10.0);
		Pen p8 = new Pen(Brand.valueOf("PARKER"), "blue", Material.valueOf("METAL"), 30, LocalDate.parse("2021-03-21"),
				LocalDate.parse("2023-05-01"), 10.0);
		System.out.println(penMap.put(p1.getId(), p1));
		System.out.println(penMap.put(p2.getId(), p2));
		System.out.println(penMap.put(p3.getId(), p3));
		System.out.println(penMap.put(p4.getId(), p4));
		System.out.println(penMap.put(p5.getId(), p5));
		System.out.println(penMap.put(p6.getId(), p6));
		System.out.println(penMap.put(p7.getId(), p7));
		System.out.println(penMap.put(p8.getId(), p8));
	}
}
