package core;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

public class Pen implements Comparable<Pen>,Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5043303744281581302L;
	
	private Integer Id;
	private Brand brand;
	private String color;
	private Material material; 
	private int stock;
	private LocalDate StockUpdateDate;
	private LocalDate StockListingDate;
	private Double Price;
	private static int count;
	static {count=0;}
	private Double Discount;
	public Pen( Brand brand, String color, Material material, int stock,LocalDate stockListingDate, LocalDate StockUpdateDate, Double price) {

		super();
		Id=++count;
		this.brand = brand;
		this.color = color;
		this.material = material;
		this.stock = stock;
		this.StockUpdateDate = StockUpdateDate;
		StockListingDate = stockListingDate;
		Price = price;
		Discount=0.0;
	}
	
	

//	public Pen(Brand brand2, String color2, Material material2, int stock2, LocalDate stockListingDate2, int price2) {
//		// TODO Auto-generated constructor stub
//	}



	@Override
	public int hashCode() {
		return Objects.hashCode(Id);
	}
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Pen)
		{
			Pen p = (Pen)obj;
			return Id==p.Id;
		}
		return false;
	}
	
	
	public Brand getBrand() {
		return brand;
	}
	public void setBrand(Brand brand) {
		this.brand = brand;
	}
	public Material getMaterial() {
		return material;
	}
	public void setMaterial(Material material) {
		this.material = material;
	}
	public String getColor() {
		return color;
	}
	
	public double getDiscount() {
		return Discount;
	}
	public void setDiscount(double discount) {
		this.Discount = discount;
		setPrice(getPrice()-getPrice()*discount/100);
	}	
		
	public void setPrice(Double price) {
		Price = price;
	}



	public Integer getId() {
		return Id;
	}
	public Double getPrice() {
		return Price;
	}
	@Override
	public String toString() {
		return "Pen [Id=" + Id + ", brand=" + brand + ", color=" + color + ", material=" + material + ", stock=" + stock
				+ ", StockUpdateDate=" + StockUpdateDate + ", StockListingDate=" + StockListingDate + ", Price=" + Price
				+ ", Discount=" + Discount + "]\n";
	}
	
	
	public int getStock() {
		return stock;
	}



	public void setStock(int stock) {
		this.stock = stock;
	}



	public LocalDate getStockUpdateDate() {
		return StockUpdateDate;
	}



	public void setStockUpdateDate(LocalDate stockUpdateDate) {
		StockUpdateDate = stockUpdateDate;
	}



	@Override
	public int compareTo(Pen o) {
		return Id.compareTo(o.Id);
		
	}
		

}
