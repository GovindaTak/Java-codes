package PenValidation;

public class PenException extends Exception {


	/**
	 * 
	 */
	private static final long serialVersionUID = 5483820857274815003L;


	public PenException(String message) {
		super(message);

	}
}
