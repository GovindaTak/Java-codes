package PenOperations;

import java.time.LocalDate;
import java.time.Period;
import java.util.Comparator;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.TreeSet;

import PenValidation.PenException;
import core.Brand;
import core.Material;
import core.Pen;

public interface PenOperations
{
	 public static void addPen(Map<Integer,Pen>penMap,Scanner sc) throws PenException

 {		System.out.println("avaliable Brand as :- ");
		 for(Brand b:Brand.values()) System.out.println(b.name());
		 System.out.println("avaliable Material as :- ");
		 for(Material c:Material.values()) System.out.println(c.name()); 
	System.out.println("Enter pen details as brand, color, material, stock "
			+ " stockListingDate, price, discount");

	Pen p1 = new Pen(Brand.valueOf(sc.next().toUpperCase()), sc.next(), Material.valueOf(sc.next().toUpperCase()), sc.nextInt(), LocalDate.now(),LocalDate.now(),sc.nextDouble());
	penMap.put(p1.getId(), p1);
	System.out.println("Pen is added");
 }
	static void updateStock(Map<Integer,Pen>penMap,Scanner sc)
	{
		System.out.println("enter penId and stock to be added :- ");
		Pen p=penMap.get(sc.nextInt());
		if(p==null) { System.out.println("invalid PenId !"); return;}
		p.setStock(p.getStock()+sc.nextInt());
		p.setStockUpdateDate(LocalDate.now());
		System.out.println("successfully updated !");
	}
	static void setDiscount(Map<Integer,Pen>penMap)
	{	
		
		penMap.values().stream()
		.filter(i->{if(fetchmonth(i).compareTo(3)>0) return true;return false;})
		.forEach(i->i.setDiscount(20));
		System.out.println("successfully updated !");
	}
	static Integer fetchmonth(Pen p)
	{
		return Period.between(p.getStockUpdateDate(),LocalDate.now()).getMonths();
	}
	static void removePens(Map<Integer,Pen>penMap)
	{	
		
		penMap.values().removeIf(i->{if(fetchmonth(i).compareTo(9)>0) return true;return false;});
		System.out.println("successfully remove !");
	}
	static void displayAll(Map<Integer,Pen>penMap)
	{
		penMap.forEach((k,v)->System.out.println(k+" "+v));
	}
	static void sortbyId(Map<Integer,Pen>penMap)
	{
		penMap.values().stream().sorted().forEach(System.out::println);
		//2nd method 
		TreeMap<Integer,Pen>tm=new TreeMap<>(penMap);
		tm.forEach((k,v)->System.out.println(k+" "+v));
	}
	static void sortbyLastUpdateDate(Map<Integer,Pen>penMap)
	{
		penMap.values().stream().sorted((p1,p2)->p1.getStockUpdateDate().compareTo(p2.getStockUpdateDate())).forEach(System.out::println);
		//2nd method 
		TreeSet<Pen>ts=new TreeSet<>(penMap.values());
		ts.stream().sorted((p1,p2)->p1.getStockUpdateDate().compareTo(p2.getStockUpdateDate())).forEach(System.out::println);
	}
	static void sortbyNameAndPrice(Map<Integer,Pen>penMap)
	{			
		Comparator<Pen>ref=((p1,p2)->{ if(p1.getBrand().compareTo(p2.getBrand())==0) return p1.getPrice().compareTo(p2.getPrice());return p1.getBrand().compareTo(p2.getBrand());});
		penMap.values().stream().sorted(ref).forEach(System.out::println);
		//2nd method 
		TreeSet<Pen>ts=new TreeSet<>(penMap.values());
		ts.stream().sorted(ref).forEach(System.out::println);
	}
	
	
}
