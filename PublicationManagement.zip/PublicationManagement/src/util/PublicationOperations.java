package util;

import java.time.LocalDate;
import java.util.Map;
import java.util.Scanner;

import core.Book;
import core.Publication;
import core.Tape;
import exception.PublicationException;
import exception.PublicationValidation;

public interface PublicationOperations extends PublicationValidation {

	static void addBook(Scanner sc,Map<String,Publication>pMap) throws PublicationException
	{
		System.out.println("enter book details :- title, price, publishDate, rating and count");
		String title=sc.next().toUpperCase();
		Publication p=pMap.get(title);
		if(p!=null) throw new PublicationException("Title already exist !");
		Book b=new Book(title,sc.nextDouble(),LocalDate.parse(sc.next()),PublicationValidation.checkRating(sc.nextInt()),sc.nextInt());
		pMap.put(title,b);
		System.out.println("successfully added !");
	}
	static void addTape(Scanner sc,Map<String,Publication>pMap) throws PublicationException
	{
		System.out.println("enter book details :- title, price, publishDate, rating and playingTime(in minutes)");
		String title=sc.next().toUpperCase();
		Publication p=pMap.get(title);
		if(p!=null) throw new PublicationException("Title already exist !");
		Tape b=new Tape(title,sc.nextDouble(),LocalDate.parse(sc.next()),PublicationValidation.checkRating(sc.nextInt()),sc.nextLong());
		pMap.put(title,b);
		System.out.println("successfully added !");
	}
//	static void sortByPublishDateDesc(Map<String,Publication>pMap)
//	{
//		pMap.values().stream().sorted((i1,i2)->i2.getPublishDate().compareTo(i1.getPublishDate())).forEach(System.out::println);
//	}
	static void sortBookByPublishDateDesc(Map<String,Publication>pMap)
	{
		pMap.values().stream()
		.filter(i->i instanceof Book)
		.sorted((i1,i2)->i2.getPublishDate().compareTo(i1.getPublishDate())).forEach(System.out::println);
	}
	static void listTop5publisRecentYear(Map<String,Publication>pMap)
	{
		pMap.values().stream()
		.filter(i->i.getPublishDate().getYear()==2023)
		.sorted((p1,p2)->((Integer)p2.getRating()).compareTo(p1.getRating()))
		.limit(5)
		.forEach(System.out::println);

	}
	static void displayAll(Map<String,Publication>pMap)
	{
		pMap.forEach((k,v)->System.out.println(v));
	}
}
