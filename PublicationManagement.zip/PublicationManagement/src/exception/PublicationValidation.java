package exception;

public interface PublicationValidation {

	public static int checkRating(int rating) throws PublicationException
	{
		if(rating>0 && rating<11 ) return rating;
		throw new PublicationException("Invalid rating !(must be between 1 to 10)");
	}
	
}
