package exception;

public class PublicationException extends Exception {

	

	public PublicationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}



}
