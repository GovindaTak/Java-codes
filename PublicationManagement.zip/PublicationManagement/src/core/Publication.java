package core;

import java.time.LocalDate;

public class Publication {

	private Integer id;
	private String title;
	private Double price;
	private LocalDate publishDate;
	private int rating;
	private static int count=0;
	public Publication(String title, Double price, LocalDate publishDate, int rating) {
		id=++count;
		this.title = title;
		this.price = price;
		this.publishDate = publishDate;
		this.rating = rating;
	}
	
	
	@Override
	public String toString() {
		return "Publication [id=" + id + ", title=" + title + ", price=" + price + ", publishDate=" + publishDate
				+ ", rating=" + rating + " ";
	}


	public String getTitle() {
		return title;
	}
	
	public LocalDate getPublishDate() {
		return publishDate;
	}
	
	public int getRating() {
		return rating;
	}
	
	
	
	
	
}
