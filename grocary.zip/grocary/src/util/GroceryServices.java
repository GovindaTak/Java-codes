package util;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;
import java.util.Map;
import java.util.Scanner;

import core.Grocery;

public interface GroceryServices {

	static void addNewItem(Scanner sc, Map<String, Grocery> groceryMap) {
		System.out.println("enter following details :- name , price and quantity to be added \n");
		Grocery gc = new Grocery(sc.next().toUpperCase(), sc.nextDouble(), sc.nextInt(), LocalDate.now(),
				LocalTime.now());
		if (groceryMap.putIfAbsent(gc.getName(), gc) != null) {
			System.out.println("already register,can't register again !");
			return;
		}
		System.out.println("successfully added");
	}

	static void update(Scanner sc, Map<String, Grocery> groceryMap) {
		System.out.println("enter following details :-item name , quantity \n");
		Grocery gc = groceryMap.get(sc.next().toUpperCase());
		if (gc == null) {
			System.out.println("invalid grocery name !");
			return;
		}
		gc.setQuantity(gc.getQuantity() + sc.nextInt());
		gc.setDate(LocalDate.now());
		gc.setTime(LocalTime.now());
		System.out.println("successfully updated");
	}

	static void displayItem(Map<String, Grocery> groceryMap) {
		groceryMap.forEach((k, v) -> System.out.println(v));
	}

	static void removeEmptyItem(Map<String, Grocery> groceryMap) {
//		groceryMap.values().stream()
//		.filter(i->i.getQuantity().equals(0))
//		.map(i->i.getName())
//		.forEach(i->groceryMap.remove(i));
		groceryMap.values().removeIf(v -> v.getQuantity().equals(0));
	}

	static void displayItemRecentUpdated(Map<String, Grocery> groceryMap, int days) {
		groceryMap.values().stream().filter(i -> {
			if (fetchdays(i).compareTo(days + 1) < 0)
				return true;
			return false;
		}).forEach(System.out::println);
	}

	static Integer fetchdays(Grocery g) {
		return Period.between(g.getDate(), LocalDate.now()).getDays();
	}

	static void populatedMap(Map<String, Grocery> groceryMap) {
		Grocery g1 = new Grocery("Milk".toUpperCase(), 28.0, 50, LocalDate.parse("2023-10-24"), LocalTime.now());
		Grocery g2 = new Grocery("tea".toUpperCase(), 10.0, 50, LocalDate.parse("2023-10-21"), LocalTime.now());
		Grocery g3 = new Grocery("coffee".toUpperCase(), 28.0, 0, LocalDate.parse("2023-10-25"), LocalTime.now());
		Grocery g5 = new Grocery("colddrink".toUpperCase(), 50.0, 35, LocalDate.parse("2023-10-23"), LocalTime.now());
		Grocery g6 = new Grocery("crud".toUpperCase(), 22.0, 0, LocalDate.parse("2023-10-22"), LocalTime.now());
		groceryMap.put(g1.getName(), g1);
		groceryMap.put(g2.getName(), g2);
		groceryMap.put(g3.getName(), g3);
		groceryMap.put(g6.getName(), g6);
		groceryMap.put(g5.getName(), g5);
	}
}
